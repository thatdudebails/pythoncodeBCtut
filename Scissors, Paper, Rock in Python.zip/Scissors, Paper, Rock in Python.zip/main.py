import random
import time
import sprconfig

spr = ["Scissors","Paper","Rock"]
CPU = random.choice(spr)

USER = input("Scissors, Paper or Rock?:")

if USER == "scissors" or USER == "Scissors":

    print("You play "+USER)
    time.sleep(1)
    print("CPU plays "+CPU)
    time.sleep(1)

    if CPU == "Rock":
        print("You lose!")
        time.sleep(0.65)
        
    elif CPU == "Paper":
        print("You win!")
        time.sleep(0.65)
        
    elif CPU == "Scissors":
        print("Tie!")
        time.sleep(0.65)
        
    else:
        print("That isn't apart of this game!")

if USER == "paper" or USER == "Paper":

    print("You play "+USER)
    time.sleep(1)
    print("CPU plays "+CPU)
    time.sleep(1)

    if CPU == "Rock":
        print("You win!")
        time.sleep(0.65)
        
    elif CPU == "Paper":
        print("Tie!")
        time.sleep(0.65)
        
    elif CPU == "Scissors":
        print("You lose!")
        time.sleep(0.65)
        
    else:
        print("That isn't apart of this game!")

if USER == "rock" or USER == "Rock":

    print("You play "+USER)
    time.sleep(1)
    print("CPU plays "+CPU)
    time.sleep(1)

    if CPU == "Rock":
        print("Tie!")
        time.sleep(0.65)
        
    elif CPU == "Paper":
        print("You lose!")
        time.sleep(0.65)
        
    elif CPU == "Scissors":
        print("You win!")
        time.sleep(0.65)
        
    else:
        print("That isn't apart of this game!")

while True:
    sprconfig.spr_game()
